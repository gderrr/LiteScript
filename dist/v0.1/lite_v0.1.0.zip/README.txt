How to install:

To install the interpreter (the executable "lite" file), run the following commands:
    sudo cp lite /usr/local/bin/
    sudo chmod +x /usr/local/bin/lite
Run "lite --version" to check that it has been correctly installed.

To install the vscode extension, simply run:
    code --install-extension litescript-0.1.6.vsix